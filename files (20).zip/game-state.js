/* ┌─────────────────────────────────────────────────────────────────────────┐
   │  MODULE 02 · SAVE / LOAD  —  defaultState · saveGame · loadGame        │
   └─────────────────────────────────────────────────────────────────────────┘ */
const defaultState = () => ({
  money: 0, totalEarned: 0,
  tutorialDone: false,
  adsDismissed: {},
  slots: [{ machine:'begin0', earned:0 }, null, null, null, null],
  ownedSlots: 5,
  unlockedTiers: [],
  wallet: { xu:0, gold:0, diamond:0, dark:0, ruby:0, rainbow:0, token:0, hexper:0, key:0 },
  // ═══ BANNER ═══
  bannerStarterDone: false,
  // ═══ CASINO ═══
  casinoStats: { gamesPlayed:0, totalWon:0, totalLost:0, biggestWin:0, hexperEarned:0 },
  casinoLastSpinTime: 0,  // throttle wheel spin: 1 spin per 30s
  casinoDailyBets: 0,     // total hexper bet today (reset daily), anti-exploit
  casinoDailyDate: '',    // 'YYYY-MM-DD' of last daily reset
  inventory: [],
  invMaxSlots: 50,
  recyclePoints: 0,
  marketStocks: { normal:[], mid:[], black:[] },
  myListings: [],
  lastStockTime: 0,
  // ═══ PROFILE ═══
  playerName: 'PlayerName',
  playerBio: '',
  // ═══ BUNDLES ═══
  factoryPlus: false,
  factoryPremium: false,
  // ═══ GIÁ TRỊ ĐỒNG TIỀN ═══
  // valueMultiplier: tự động tính theo thời gian chơi (sqrt), tối đa 10x sau ~100h
  // Sau 1 phút: x1.01, sau 10 phút: x1.105, sau 1 giờ: x1.817, sau 1 ngày: x1138x
  valueMultiplier: 1.0,
  playedSeconds: 0,
  // ═══ INTERNET ═══
  inetPackage: null,    // 'basic' | 'balance' | 'speed' | 'free'
  inetExpiry: 0,        // timestamp ms
  inetBargainBonus: 0,  // free bargain(s) from speed package
  freeInetUsedDate: '', // 'YYYY-MM-DD' of last free plan use
  osVersion: 2,         // 2 | 3 | 4 | 5
  // 255025502550 BOSS HISTORY 255025502550
  // bossHistory[host] = { badCount, mediumCount, goodDone, banned }
  bossHistory: {},
  // ═══ LOTTERY ═══
  lotteryHistory: [],
  lotteryBet: 10,
  lotteryMode: 'jackpot',
  // ═══ MATERIALS SHOP ═══
  matBonuses: {
    speedBoost: 1.0,       // multiplier on machine rate (on top of valueMultiplier)
    slotBoost: 0,          // extra slot capacity bonus
    autoCollect: false,    // auto-collect from market
    inetFreeSlots: 0,      // free internet reconnects
    lotteryLuckBonus: 0,   // flat bonus to lottery multipliers
    recycleBoost: 1.0,     // multiplier on recycle points earned
    powerEfficiency: 1.0,  // power drain rate multiplier (lower = slower drain)
    valuePumpMult: 1.0,    // bonus multiplier from Value Pump upgrades (separate from time-based vm)
  },
  matPurchased: {},        // id → count purchased
  powerSeconds: 0,          // remaining power in seconds (0 = no power)
  powerOutageTriggered: false, // has the 20min outage happened
  reservePowerUsed: false,  // reserve power already used this outage
  totalPowerBought: 0,      // total seconds of fuel ever bought
  manualPowerOff: false,    // player manually turned off power
  // ═══ LOAN ═══
  loan: {
    active: false,          // has an active loan
    principal: 0,           // amount borrowed
    interest: 0,            // accumulated interest
    borrowedAt: 0,          // timestamp ms when loan was taken
    lockedFeatures: false,  // features locked after 30 min
    bankruptTriggered: false,// bankruptcy triggered after 60 min
    loanCount: 0,           // total number of loans taken (for escalating interest)
  },
  // ═══ TAX ═══
  tax: {
    bills: [],       // [{id, amount, issuedAt, item, paidAt, penaltyMult}]
    banUntil: 0,     // timestamp ms — banned from buying until this time
    banCount: 0,     // how many bans accumulated (for escalating ban duration)
    totalPaid: 0,    // total tax paid ever
  },
  // ═══ SKIN ═══
  skinCollection: { icons: [], badges: [] },
  equippedIcon: null,    // profile icon id
  equippedBadge: null,   // badge id shown next to name
});

let G = loadGame();

// Re-apply mat bonuses from purchase history to fix effects after reload
// matBonuses are cumulative so we reset to defaults then re-apply all purchases
(function reapplyMatBonuses() {
  if (!G.matPurchased || Object.keys(G.matPurchased).length === 0) return;
  // Reset to default values before re-applying
  const def = defaultState().matBonuses;
  G.matBonuses = {
    speedBoost: def.speedBoost,
    slotBoost: 0,
    autoCollect: def.autoCollect,
    inetFreeSlots: def.inetFreeSlots,
    lotteryLuckBonus: def.lotteryLuckBonus,
    recycleBoost: def.recycleBoost,
    powerEfficiency: def.powerEfficiency,
  };
  // Re-apply each purchased item the correct number of times
  // (MAT_ITEMS not defined yet at this point — defer to after MAT_ITEMS is defined)
  // This runs as a deferred call from initGame via window._reapplyMatBonusesDeferred
  window._matPurchasedToReapply = G.matPurchased;
})();

// Also try to load from artifact persistent storage (async, overwrites if found)
if (window.storage) {
  window.storage.get(SAVE_KEY).then(result => {
    if (result && result.value) {
      const loaded = parseLoadedData(result.value);
      if (loaded && loaded.totalEarned !== undefined) {
        G = loaded;
        renderAll();
        setTimeout(() => showNotif('✅ Đã tải tiến trình (cloud)!'), 400);
        // Restore power state
        setTimeout(() => {
          if (G.manualPowerOff) { applyPowerOutageLock(true); showManualPowerOff(); switchTab('electricity'); }
          else if (G.powerOutageTriggered && G.powerSeconds <= 0) { applyPowerOutageLock(true); showOutageScreen(); switchTab('electricity'); }
        }, 500);
      }
    }
  }).catch(()=>{});
}

function saveGame(manual) {
  const data = JSON.stringify(G);
  // Try artifact persistent storage first
  if (window.storage) {
    window.storage.set(SAVE_KEY, data).catch(()=>{});
  }
  // Also keep localStorage as fallback
  try { localStorage.setItem(SAVE_KEY, data); } catch(e){}
  if (manual) showNotif('💾 Đã lưu!');
}

async function loadGameAsync() {
  // Try artifact storage first
  if (window.storage) {
    try {
      const result = await window.storage.get(SAVE_KEY);
      if (result && result.value) {
        return parseLoadedData(result.value);
      }
    } catch(e){}
  }
  // Fallback to localStorage
  try {
    const s = localStorage.getItem(SAVE_KEY);
    if (s) return parseLoadedData(s);
  } catch(e){ console.warn('Load error:', e); }
  return null;
}

function loadGame() {
  // Sync load from localStorage only (async load handled after init)
  try {
    const s = localStorage.getItem(SAVE_KEY);
    if (s) return parseLoadedData(s);
  } catch(e){ console.warn('Load error:', e); }
  return defaultState();
}

function parseLoadedData(s) {
  try {
      const p = JSON.parse(s);
      const d = defaultState();
      if (!p.wallet) p.wallet = d.wallet;
      if (p.ownedSlots === undefined) p.ownedSlots = 5;
      if (!p.inventory) p.inventory = [];
      if (!p.invMaxSlots) p.invMaxSlots = 50;
      if (!p.recyclePoints) p.recyclePoints = 0;
      if (!p.marketStocks) p.marketStocks = {normal:[],mid:[],black:[]};
      if (!p.marketStocks.normal) p.marketStocks.normal = [];
      if (!p.marketStocks.mid) p.marketStocks.mid = [];
      if (!p.marketStocks.black) p.marketStocks.black = [];
      if (!p.myListings) p.myListings = [];
      if (!p.lastStockTime) p.lastStockTime = 0;
      if (!p.boughtBundles) p.boughtBundles = [];
      if (!p.boughtTokenBundles) p.boughtTokenBundles = [];
      if (!p.wallet.token) p.wallet.token = 0;
      if (!p.wallet.hexper) p.wallet.hexper = 0;
      if (p.wallet.key === undefined) p.wallet.key = 0;
      if (p.bannerStarterDone === undefined) p.bannerStarterDone = false;
      if (!p.casinoStats) p.casinoStats = { gamesPlayed:0, totalWon:0, totalLost:0, biggestWin:0, hexperEarned:0 };
      if (p.casinoLastSpinTime === undefined) p.casinoLastSpinTime = 0;
      if (p.casinoDailyBets === undefined) p.casinoDailyBets = 0;
      if (!p.casinoDailyDate) p.casinoDailyDate = '';
      if (!p.taxEvadeTickets) p.taxEvadeTickets = 0;
      if (!p.debtEvadeTickets) p.debtEvadeTickets = 0;
      if (!p.permanentSpeedInternet) p.permanentSpeedInternet = false;
      // Migrate: clamp old exponential valueMultiplier; recalculate from playedSeconds
      { const t = p.playedSeconds || 0;
        const fromTime = Math.min(1 + 4 * Math.sqrt(t / 72000), 10);
        // If saved value is way higher than expected (old formula), recalculate
        if (!p.valueMultiplier || p.valueMultiplier < 1 || p.valueMultiplier > fromTime * 20) {
          p.valueMultiplier = fromTime;
        } }
      if (!p.playedSeconds) p.playedSeconds = 0;
      if (p.inetExpiry === undefined) p.inetExpiry = 0;
      if (!p.inetPackage) p.inetPackage = null;
      if (p.inetBargainBonus === undefined) p.inetBargainBonus = 0;
      if (!p.freeInetUsedDate) p.freeInetUsedDate = '';
      if (!p.bossHistory) p.bossHistory = {};
      if (p.osUpdated === undefined) p.osUpdated = false;
      if (p.mobileNetActive === undefined) p.mobileNetActive = false;
      if (p.inetDiscount === undefined) p.inetDiscount = false;
      if (p.osVersion === undefined) p.osVersion = p.osUpdated ? 3 : 2;
      if (p.osV4Updated === undefined) p.osV4Updated = false;
      if (p.osV5Updated === undefined) p.osV5Updated = false;
      if (!p.unlockedTiers) p.unlockedTiers = [];
      if (!p.slots || !Array.isArray(p.slots)) p.slots = d.slots;
      if (p.totalEarned === undefined) p.totalEarned = 0;
      if (!p.lotteryHistory) p.lotteryHistory = [];
      if (!p.lotteryBet) p.lotteryBet = 10;
      if (!p.lotteryMode) p.lotteryMode = 'jackpot';
      if (p.powerSeconds === undefined) p.powerSeconds = 0;
      if (p.powerOutageTriggered === undefined) p.powerOutageTriggered = false;
      if (p.reservePowerUsed === undefined) p.reservePowerUsed = false;
      if (p.totalPowerBought === undefined) p.totalPowerBought = 0;
      if (p.manualPowerOff === undefined) p.manualPowerOff = false;
      if (!p.matBonuses) p.matBonuses = defaultState().matBonuses;
      // Always ensure all matBonus fields exist with defaults
      const defMat = defaultState().matBonuses;
      if (p.matBonuses.speedBoost === undefined)       p.matBonuses.speedBoost = defMat.speedBoost;
      if (p.matBonuses.slotBoost === undefined)        p.matBonuses.slotBoost = defMat.slotBoost;
      if (p.matBonuses.autoCollect === undefined)      p.matBonuses.autoCollect = defMat.autoCollect;
      if (p.matBonuses.inetFreeSlots === undefined)    p.matBonuses.inetFreeSlots = defMat.inetFreeSlots;
      if (p.matBonuses.lotteryLuckBonus === undefined) p.matBonuses.lotteryLuckBonus = defMat.lotteryLuckBonus;
      if (p.matBonuses.recycleBoost === undefined)     p.matBonuses.recycleBoost = defMat.recycleBoost;
      if (p.matBonuses.powerEfficiency === undefined)  p.matBonuses.powerEfficiency = defMat.powerEfficiency;
      if (p.matBonuses.valuePumpMult === undefined)     p.matBonuses.valuePumpMult = defMat.valuePumpMult;
      if (!p.matPurchased) p.matPurchased = {};
      if (!p.loan) p.loan = defaultState().loan;
      if (p.loan.lockedFeatures === undefined) p.loan.lockedFeatures = false;
      if (p.loan.bankruptTriggered === undefined) p.loan.bankruptTriggered = false;
      if (p.loan.loanCount === undefined) p.loan.loanCount = 0;
      if (!p.tax) p.tax = defaultState().tax;
      if (!p.tax.bills) p.tax.bills = [];
      if (p.tax.banUntil === undefined) p.tax.banUntil = 0;
      if (p.tax.banCount === undefined) p.tax.banCount = 0;
      if (p.tax.totalPaid === undefined) p.tax.totalPaid = 0;
      if (p.tutorialDone === undefined) p.tutorialDone = false;
      if (!p.adsDismissed) p.adsDismissed = {};
      // Profile
      if (!p.playerName) p.playerName = 'PlayerName';
      if (p.playerBio === undefined) p.playerBio = '';
      // Bundle flags
      if (p.factoryPlus === undefined) p.factoryPlus = false;
      if (p.factoryPremium === undefined) p.factoryPremium = false;
      // Skin
      if (!p.skinCollection) p.skinCollection = { icons: [], badges: [] };
      if (!p.skinCollection.icons) p.skinCollection.icons = [];
      if (!p.skinCollection.badges) p.skinCollection.badges = [];
      if (p.equippedIcon === undefined) p.equippedIcon = null;
      if (p.equippedBadge === undefined) p.equippedBadge = null;
      return p;
  } catch(e){ console.warn('Parse error:', e); }
  return defaultState();
}
function resetGame() {
  if (!confirm('Xóa toàn bộ?')) return;
  localStorage.removeItem(SAVE_KEY);
  if (window.storage) window.storage.delete(SAVE_KEY).catch(()=>{});
  G = defaultState();
  renderAll();
  showNotif('🗑 Đã reset!');
}

// ═══════════════════════════════════════════════════════
//  RESET PASSWORD SYSTEM
// ═══════════════════════════════════════════════════════
const RESET_PW_KEY = 'factory_reset_pw';

function _getResetPassword() {
  try { return localStorage.getItem(RESET_PW_KEY) || null; } catch(e) { return null; }
}
function _saveResetPassword(pw) {
  try { localStorage.setItem(RESET_PW_KEY, pw); } catch(e) {}
}

function updateResetPwStatus() {
  const el = document.getElementById('reset-pw-status');
  if (!el) return;
  const pw = _getResetPassword();
  el.textContent = pw ? '✅ Đã đặt mật mã (' + pw.length + ' ký tự)' : '⚠️ Chưa đặt mật mã';
  el.style.color = pw ? '#4ade80' : '#f59e0b';
}

function resetGameWithPassword() {
  const pw = _getResetPassword();
  if (!pw) {
    // Lần đầu — yêu cầu đặt mật mã, KHÔNG reset
    showSetResetPasswordPopup();
  } else {
    // Đã có mật mã — yêu cầu nhập để xác nhận
    showEnterResetPasswordPopup();
  }
}

function showSetResetPasswordPopup() {
  const existing = document.getElementById('reset-pw-popup');
  if (existing) existing.remove();
  const overlay = document.createElement('div');
  overlay.id = 'reset-pw-popup';
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.88);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(6px)';
  overlay.innerHTML = `
    <div style="background:linear-gradient(135deg,#0d1117,#1a0a2e);border:2px solid #4c1d9566;border-radius:16px;padding:26px 22px;width:100%;max-width:340px;box-shadow:0 0 40px rgba(124,58,237,0.3)">
      <div style="text-align:center;margin-bottom:18px">
        <div style="font-size:36px;margin-bottom:8px">🔐</div>
        <div style="font-size:16px;font-weight:800;color:#a78bfa;margin-bottom:6px">Đặt Mật Mã Reset</div>
        <div style="font-size:12px;color:#6b7280;line-height:1.5">Lần đầu nhấn Xóa &amp; Reset bạn cần đặt mật mã bảo vệ.<br>Lần sau sẽ yêu cầu nhập mật mã này.</div>
      </div>
      <div style="margin-bottom:10px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Mật mã mới</div>
        <input id="rpop-pw1" type="password" placeholder="Nhập mật mã..." autocomplete="new-password"
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #4c1d9555;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box">
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Xác nhận mật mã</div>
        <input id="rpop-pw2" type="password" placeholder="Nhập lại mật mã..." autocomplete="new-password"
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #4c1d9555;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box">
      </div>
      <div id="rpop-err" style="font-size:12px;color:#f87171;min-height:16px;margin-bottom:10px;text-align:center"></div>
      <div style="display:flex;gap:10px">
        <button onclick="document.getElementById('reset-pw-popup').remove()" style="flex:1;padding:10px;background:#1f2937;color:#9ca3af;border:1px solid #374151;border-radius:9px;cursor:pointer;font-size:13px;font-weight:600">Hủy</button>
        <button onclick="_confirmSetResetPassword()" style="flex:1;padding:10px;background:linear-gradient(135deg,#1a0a2e,#2d1047);color:#a78bfa;border:1.5px solid #7c3aed66;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700">✅ Đặt Mật Mã</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => { const el = document.getElementById('rpop-pw1'); if(el) el.focus(); }, 100);
}

function _confirmSetResetPassword() {
  const pw1 = (document.getElementById('rpop-pw1') || {}).value || '';
  const pw2 = (document.getElementById('rpop-pw2') || {}).value || '';
  const errEl = document.getElementById('rpop-err');
  if (!pw1) { errEl.textContent = '⚠️ Vui lòng nhập mật mã!'; return; }
  if (pw1.length < 4) { errEl.textContent = '⚠️ Mật mã phải có ít nhất 4 ký tự!'; return; }
  if (pw1 !== pw2) { errEl.textContent = '❌ Mật mã không khớp!'; return; }
  _saveResetPassword(pw1);
  document.getElementById('reset-pw-popup').remove();
  updateResetPwStatus();
  showNotif('🔐 Đã đặt mật mã reset thành công!');
}

function showEnterResetPasswordPopup() {
  const existing = document.getElementById('reset-pw-popup');
  if (existing) existing.remove();
  const overlay = document.createElement('div');
  overlay.id = 'reset-pw-popup';
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.88);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(6px)';
  overlay.innerHTML = `
    <div style="background:linear-gradient(135deg,#0d1117,#1a0808);border:2px solid #991b1b66;border-radius:16px;padding:26px 22px;width:100%;max-width:340px;box-shadow:0 0 40px rgba(248,113,113,0.2)">
      <div style="text-align:center;margin-bottom:18px">
        <div style="font-size:36px;margin-bottom:8px">🗑️</div>
        <div style="font-size:16px;font-weight:800;color:#f87171;margin-bottom:6px">Xác Nhận Xóa & Reset</div>
        <div style="font-size:12px;color:#6b7280;line-height:1.5">Nhập mật mã để xác nhận.<br><span style="color:#f87171;font-weight:600">Hành động này sẽ xóa toàn bộ dữ liệu!</span></div>
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Mật mã</div>
        <input id="rpop-enter" type="password" placeholder="Nhập mật mã..." autocomplete="current-password"
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #991b1b55;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box"
          onkeydown="if(event.key==='Enter')_confirmEnterResetPassword()">
      </div>
      <div id="rpop-err" style="font-size:12px;color:#f87171;min-height:16px;margin-bottom:10px;text-align:center"></div>
      <div style="display:flex;gap:10px">
        <button onclick="document.getElementById('reset-pw-popup').remove()" style="flex:1;padding:10px;background:#1f2937;color:#9ca3af;border:1px solid #374151;border-radius:9px;cursor:pointer;font-size:13px;font-weight:600">Hủy</button>
        <button onclick="_confirmEnterResetPassword()" style="flex:1;padding:10px;background:linear-gradient(135deg,#2a0e0e,#3b1a1a);color:#f87171;border:1.5px solid #991b1b66;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700">🗑 Xóa & Reset</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => { const el = document.getElementById('rpop-enter'); if(el) el.focus(); }, 100);
}

function _confirmEnterResetPassword() {
  const entered = (document.getElementById('rpop-enter') || {}).value || '';
  const errEl = document.getElementById('rpop-err');
  const pw = _getResetPassword();
  if (!entered) { errEl.textContent = '⚠️ Vui lòng nhập mật mã!'; return; }
  if (entered !== pw) { errEl.textContent = '❌ Mật mã không đúng!'; return; }
  document.getElementById('reset-pw-popup').remove();
  // Thực hiện reset
  localStorage.removeItem(SAVE_KEY);
  if (window.storage) window.storage.delete(SAVE_KEY).catch(()=>{});
  G = defaultState();
  renderAll();
  showNotif('🗑 Đã reset toàn bộ!');
}

function showChangeResetPassword() {
  const existing = document.getElementById('reset-pw-popup');
  if (existing) existing.remove();
  const hasPw = !!_getResetPassword();
  const overlay = document.createElement('div');
  overlay.id = 'reset-pw-popup';
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.88);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(6px)';
  overlay.innerHTML = `
    <div style="background:linear-gradient(135deg,#0d1117,#1a0a2e);border:2px solid #4c1d9566;border-radius:16px;padding:26px 22px;width:100%;max-width:340px;box-shadow:0 0 40px rgba(124,58,237,0.3)">
      <div style="text-align:center;margin-bottom:18px">
        <div style="font-size:36px;margin-bottom:8px">✏️</div>
        <div style="font-size:16px;font-weight:800;color:#a78bfa;margin-bottom:4px">Đổi Mật Mã Reset</div>
      </div>
      ${hasPw ? `
      <div style="margin-bottom:10px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Mật mã hiện tại</div>
        <input id="rpop-old" type="password" placeholder="Nhập mật mã hiện tại..."
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #4c1d9555;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box">
      </div>` : ''}
      <div style="margin-bottom:10px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Mật mã mới</div>
        <input id="rpop-pw1" type="password" placeholder="Nhập mật mã mới..." autocomplete="new-password"
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #4c1d9555;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box">
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:12px;color:#9ca3af;margin-bottom:5px">Xác nhận mật mã mới</div>
        <input id="rpop-pw2" type="password" placeholder="Nhập lại mật mã mới..." autocomplete="new-password"
          style="width:100%;padding:10px 14px;background:#0d1117;border:1.5px solid #4c1d9555;border-radius:9px;color:#e2e8f0;font-size:14px;outline:none;box-sizing:border-box">
      </div>
      <div id="rpop-err" style="font-size:12px;color:#f87171;min-height:16px;margin-bottom:10px;text-align:center"></div>
      <div style="display:flex;gap:10px">
        <button onclick="document.getElementById('reset-pw-popup').remove()" style="flex:1;padding:10px;background:#1f2937;color:#9ca3af;border:1px solid #374151;border-radius:9px;cursor:pointer;font-size:13px;font-weight:600">Hủy</button>
        <button onclick="_confirmChangeResetPassword(${hasPw})" style="flex:1;padding:10px;background:linear-gradient(135deg,#1a0a2e,#2d1047);color:#a78bfa;border:1.5px solid #7c3aed66;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700">💾 Lưu</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => {
    const el = document.getElementById('rpop-old') || document.getElementById('rpop-pw1');
    if(el) el.focus();
  }, 100);
}

function _confirmChangeResetPassword(hasPw) {
  const errEl = document.getElementById('rpop-err');
  if (hasPw) {
    const oldPw = (document.getElementById('rpop-old') || {}).value || '';
    if (oldPw !== _getResetPassword()) { errEl.textContent = '❌ Mật mã hiện tại không đúng!'; return; }
  }
  const pw1 = (document.getElementById('rpop-pw1') || {}).value || '';
  const pw2 = (document.getElementById('rpop-pw2') || {}).value || '';
  if (!pw1) { errEl.textContent = '⚠️ Vui lòng nhập mật mã mới!'; return; }
  if (pw1.length < 4) { errEl.textContent = '⚠️ Mật mã phải có ít nhất 4 ký tự!'; return; }
  if (pw1 !== pw2) { errEl.textContent = '❌ Mật mã không khớp!'; return; }
  _saveResetPassword(pw1);
  document.getElementById('reset-pw-popup').remove();
  updateResetPwStatus();
  showNotif('🔐 Đã cập nhật mật mã reset!');
}

